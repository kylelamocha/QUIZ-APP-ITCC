package android.example.quiz_app

//QUESTIONAIRES
object Constants {

    const val TOTAL_QUESTIONS: String = "total_question"
    const val CORRECT_ANSWERS: String = "correct_answers"


    fun getQuestions(): ArrayList <Question>{
        val questionsList = ArrayList <Question>()

        //1
        val que1 = Question ( 1,"What is the original name of Google?",
         R.drawable.images,
            "Googel",
            "Backrub",
            "Googles",
            "Googol",
            2
        )
        questionsList.add(que1)

        //2
        val que2 = Question ( 2,"Who are the creators of Google?",
            R.drawable.unnamed,
            "Bill Gates and Stephen Hawking",
            "Kara Swisher and Elon Musk",
            "Larry Page and Sergey Brin",
            "Mark Zuckerberg and Linus Sebastian",
            3
        )
        questionsList.add(que2)

        //3
        val que3 = Question ( 3,"What is name of Google's search technology?",
            R.drawable.gogo,
            "PageRank",
            "Duo",
            "Googles",
            "Anonymous",
            1
        )
        questionsList.add(que3)

        //4
        val que4 = Question ( 4,"When was Google first used?",
            R.drawable.go,
            "August 1996",
            "September 1998",
            "July 1989",
            "November 1999",
            1
        )
        questionsList.add(que4)


        //5
        val que5= Question ( 5,"What does Google's headquarters called?",
            R.drawable.gogogo,
            "Google Doodle",
            "Larry Page",
            "Bonobo",
            "Googleplex",
            4
        )
        questionsList.add(que5)


        return questionsList
    }
}